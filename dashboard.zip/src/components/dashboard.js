import React,{useState} from 'react'

import Sidebar from './sidebar'
import Topbar from './topbar'
import Main from './main'

const Dashboard = () => {
    const [toggle, setToggle] = useState(false)
    return (
        <div className="dashboard">
            <Topbar />
            <Sidebar toggle={toggle} setToggle={setToggle} />
            <Main toggle={toggle}/>
        </div>
    )
}

export default Dashboard

import React from 'react'
import clsx from 'clsx';

import TelemonConfig from './table';

const Main = ({toggle}) => {

    return (
        <div className={clsx({ "main":true ,"fullMain":!toggle,"halfMain":toggle})} style={{
            
        }}>
           <TelemonConfig/>
        </div>
    )
}

export default Main

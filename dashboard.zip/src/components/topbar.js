import React from 'react'


const Topbar = () => {

    return (
        <div className="topbar">
            <span className="heading">Heading</span>
        </div>
    )
}

export default Topbar

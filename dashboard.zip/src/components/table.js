import React from 'react';
import MaterialTable from 'material-table';



class TelemonConfig extends React.Component {
    constructor() {
        super();
        this.state = {
            configuredialogstate: false,
            selectedgateway:null,
            resetdialogstate: false,
            columns: [
                { title: 'Id', field: 'Id' },
                { title: 'Type', field: 'Type' },
                { title: 'MBAddress', field: 'MBAddress' },
                { title: 'RegisterCount', field: 'RegisterCount' }, 
                { title: 'Format', field: 'Format' },
                { title: 'Scale', field: 'Scale' },
                { title: 'Tag', field: 'Tag' },
                { title: 'Device', field: 'Device' },
                { title: 'QOS', field: 'QOS' },
                { title: 'SlaveId', field: 'SlaveId' },

            ],
            data: []

        };
        this.handleOnAdd = this.handleOnAdd.bind(this);
        this.handleOnUpdate = this.handleOnUpdate.bind(this);
        this.handleOnDelete = this.handleOnDelete.bind(this);
    }

    componentDidMount() {

    }

   
    handleOnAdd(newData) {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve();
                const data = [...this.state.data];
                data.push(newData);
                this.setState({ ...this.state, data });
            }, 100);
        });
    }

    handleOnUpdate(newData, oldData) {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve();
                const data = [...this.state.data];
                let index = 0;
                for (var i = 0; i < data.length; i++) {
                    if (data[i].Id === oldData.Id) {
                        data[i] = newData;
                        this.setState({ ...this.state, data });
                    }
                }


            }, 100);
        });
    }

    handleOnDelete(oldData) {
        return new Promise(resolve => {
            setTimeout(() => {
                resolve();
                const data = [...this.state.data];
                data.splice(data.indexOf(oldData), 1);
                this.setState({ ...this.state, data });
            }, 100);
        });
    }

    

  

    render() {
        return (
            <div>
                <MaterialTable
                    title="DEVICE CONFIGURATION"
                    columns={this.state.columns}
                    data={this.state.data} 
                    editable={{
                        onRowAdd: this.handleOnAdd,
                        onRowUpdate: this.handleOnUpdate,
                        onRowDelete: this.handleOnDelete,
                    }}
                    options={
                        {
                            actionsColumnIndex: -1,
                            headerStyle: {
                                backgroundColor: '#526c69',
                                color: '#FFF'
                            },
                            exportButton: true
                        }
                    }
                />
            </div>
        )
    }
}



export default TelemonConfig;


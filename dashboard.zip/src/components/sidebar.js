import React from 'react'
import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';

// Be sure to include styles at some point, probably during your bootstraping
import '@trendmicro/react-sidenav/dist/react-sidenav.css';
import user from '../assets/user.png'
import group from '../assets/group.png'
import ip from '../assets/ip.png'

const Sidebar = ({
    toggle,
    setToggle
}) => {
    return (
        <SideNav className="sidebar"
    onSelect={(selected) => {
        // Add your code here
    }}
>
    <Toggle expanded={toggle} onClick={()=>{setToggle(!toggle);console.log(toggle)}}/>
        <SideNav.Nav defaultSelected="user" >
            <NavItem eventKey="user">
                <NavIcon>
                <img src={user}/>
                </NavIcon>
                <NavText>
                    User Management
                </NavText>
            </NavItem>
            <NavItem eventKey="group">
                <NavIcon>
                <img src={group}/>
                </NavIcon>
                <NavText>
                    Gropu Management
                </NavText>
                <NavItem eventKey="charts/linechart">
                    <NavText>
                        Line Chart
                    </NavText>
                </NavItem>
                <NavItem eventKey="charts/barchart">
                    <NavText>
                        Bar Chart
                    </NavText>
                </NavItem>
            </NavItem>
            <NavItem eventKey="ip">
                <NavIcon>
                <img src={ip}/>
                </NavIcon>
                <NavText>
                    IP Management
                </NavText>
            </NavItem>
        </SideNav.Nav>
    </SideNav>
    )
}

export default Sidebar
